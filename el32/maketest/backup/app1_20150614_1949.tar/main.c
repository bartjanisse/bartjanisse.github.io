
#include "../common/common.h"
#include "../common/names.h"


int
main()
{
	print(TXT1);
	return 0;
}
