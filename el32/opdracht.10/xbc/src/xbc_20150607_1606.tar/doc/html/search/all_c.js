var searchData=
[
  ['rb',['RB',['../struct_buttons.html#a6d7bc7609cc3e233e0044813780ab2d4',1,'Buttons']]],
  ['right_5fstick_5fx',['Right_stick_X',['../struct_buttons.html#a7fa6690fc1458901c72ef7997270fea7',1,'Buttons']]],
  ['right_5fstick_5fy',['Right_stick_Y',['../struct_buttons.html#acabf34ad61f696e479607ca456f25fc4',1,'Buttons']]],
  ['right_5ftrigger',['Right_trigger',['../struct_buttons.html#a79bedbdbd5a48a621f7a6d8a06b82bf8',1,'Buttons']]],
  ['rotate',['rotate',['../_controller_8h.html#a1e4b1d1d1b6272a280f18efef4db3f5ea26d30288a9243336cb334fe193a7fd61',1,'Controller.h']]],
  ['rs_5fpress',['RS_PRESS',['../struct_buttons.html#a060553e2ecadce74e0f2a06990caeb9f',1,'Buttons']]]
];
