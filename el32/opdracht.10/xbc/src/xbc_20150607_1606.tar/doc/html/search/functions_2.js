var searchData=
[
  ['getandclaimhandle',['getAndClaimHandle',['../_devices_8c.html#a5adef2db23a694e016b1dc6a9d1b27a4',1,'getAndClaimHandle(uint16_t vendor_id, uint16_t product_id):&#160;Devices.c'],['../_devices_8h.html#af4d44651871175f88640bc44f5acc9e8',1,'getAndClaimHandle(uint16_t vendor_id, uint16_t product_id):&#160;Devices.c']]],
  ['getcontrollerinput',['getControllerInput',['../_controller_8c.html#ada7bb69f660d82b468b40aeab8ad8c9d',1,'getControllerInput(libusb_device_handle *handle, Buttons *buttons):&#160;Controller.c'],['../_controller_8h.html#ada7bb69f660d82b468b40aeab8ad8c9d',1,'getControllerInput(libusb_device_handle *handle, Buttons *buttons):&#160;Controller.c']]]
];
