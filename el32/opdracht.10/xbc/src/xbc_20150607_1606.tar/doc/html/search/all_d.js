var searchData=
[
  ['setcontrollerleds',['setControllerLeds',['../_controller_8c.html#acc1e0a36aea4db307a6700c13a74b4fb',1,'setControllerLeds(libusb_device_handle *handle, Leds led):&#160;Controller.c'],['../_controller_8h.html#acc1e0a36aea4db307a6700c13a74b4fb',1,'setControllerLeds(libusb_device_handle *handle, Leds led):&#160;Controller.c']]],
  ['setcontrollerrumble',['setControllerRumble',['../_controller_8c.html#ae7cb117322f01a153aa80f498dd1a139',1,'setControllerRumble(libusb_device_handle *handle, uint16_t speed):&#160;Controller.c'],['../_controller_8h.html#ae7cb117322f01a153aa80f498dd1a139',1,'setControllerRumble(libusb_device_handle *handle, uint16_t speed):&#160;Controller.c']]],
  ['spare',['SPARE',['../struct_buttons.html#aaf3a9df2c4578bd2d3591334e0d9ace5',1,'Buttons']]],
  ['start',['START',['../struct_buttons.html#a991094a2cc72be82f14668a78f8c2cc6',1,'Buttons']]]
];
