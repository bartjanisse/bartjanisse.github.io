var searchData=
[
  ['how_20it_20all_20works',['How it all works',['../page3.html',1,'']]]
];
