var searchData=
[
  ['democontroller',['demoController',['../_demo_controller_8c.html#a49607f4d777de5ddf401059f5ad9e672',1,'demoController(libusb_device_handle *handle):&#160;DemoController.c'],['../_demo_controller_8h.html#a923ffc46f2f35963ae3da6102026389c',1,'demoController(libusb_device_handle *h):&#160;DemoController.c']]]
];
