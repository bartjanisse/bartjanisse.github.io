var searchData=
[
  ['setleds',['setLeds',['../controller_8c.html#adb132c1b27b902965b8f7aedc42e022c',1,'setLeds(libusb_device_handle *handle, Leds led):&#160;controller.c'],['../controller_8h.html#adb132c1b27b902965b8f7aedc42e022c',1,'setLeds(libusb_device_handle *handle, Leds led):&#160;controller.c']]],
  ['spare',['SPARE',['../struct_buttons.html#aaf3a9df2c4578bd2d3591334e0d9ace5',1,'Buttons']]],
  ['start',['START',['../struct_buttons.html#a991094a2cc72be82f14668a78f8c2cc6',1,'Buttons']]]
];
