/** @file main.c
 *  @brief Function prototypes for the console driver.
 *
 *  @details This contains the prototypes for xxxxxxxxxxxxxxxxxxxxxxx
 *
 *  @author A.W Janisse
 *	@version 1.0  @date 28-05-2015
 *  
 */

#include <stdio.h>
#include <unistd.h>     // for sleep(), usleep()
#include <libusb-1.0/libusb.h>
#include "devices.h"
#include "controller.h"

#define THRESHOLD 150	//!< Treshold level for displaying analog values

/** @brief this main func....................
 *  
 *  @ return ??????
 */
int
main(int argc, char *argv[])
{
	int 					/*error, transferred,*/r;
	ssize_t 				devCntr = 0;
	libusb_device_handle 	*h;
	libusb_device 			**devices;
	libusb_context 			*ctx = NULL;
	Buttons 				buttons;


	r = libusb_init(&ctx);
	if(r < 0) 
	{
        fprintf(stderr, "Init Error "); //there was an error
        return (1);
    }
    libusb_set_debug(ctx, 3); //set verbosity level to 3, as suggested in the documentation


	devCntr = libusb_get_device_list(NULL, &devices);

	if (devCntr < 0)
		return (int) devCntr;

	printAllDevices(devices);

	libusb_free_device_list(devices, 1);

	h = libusb_open_device_with_vid_pid(ctx, VENDOR_ID, VENDOR_PROD);
	if (h == NULL) {
		fprintf(stderr, "*** Failed to open device. Is it plugged in and did you run with sudo?\n");
		return (1);
	}

	//find out if kernel driver is attached
	if(libusb_kernel_driver_active(h, 0) == 1)  
	{
        fprintf(stdout, "Kernel Driver Active\n");

        if(libusb_detach_kernel_driver(h, 0) == 0) //detach it
        {
        	fprintf(stdout, "Kernel Driver Detached!\n");
        }
    }

	//claim interface 0 (the first) of device (mine had jsut 1)
	r = libusb_claim_interface(h, 0); 
    if(r < 0) 
    {
        fprintf(stderr, "Cannot Claim Interface\n");
        return (1);
    }

    fprintf(stdout, "Claimed Interface\n");

    fprintf(stdout, "All led's off...\n");
    setLeds(h, all_off);
    sleep(1);
    fprintf(stdout, "Rotate led's...\n");
    setLeds(h, rotate);


    sleep(1);
    fprintf(stdout, "Rumble on...\n");
	rumble(h, 0xe3a6);
	sleep(1);
	fprintf(stdout, "Rumble off...\n");
	rumble(h, 0x00);

	fprintf(stdout, "All led's off...\n");
    setLeds(h, all_off);


    fprintf(stdout, "Press a button...\n");
    int i;
    for (i = 0; i < 2000; ++i)
    {
    	getInput(h, &buttons);

	 	if(buttons.D_UP)  	 fprintf(stdout, "Button D-up pressed...\n");		
		if(buttons.D_DN) 	 fprintf(stdout, "Button D-down pressed...\n");	
		if(buttons.D_LEFT)   fprintf(stdout, "Button D-left pressed...\n");
		if(buttons.D_RIGHT)  fprintf(stdout, "Button D-right pressed...\n");
		if(buttons.START) 	 fprintf(stdout, "Button Start pressed...\n");
		if(buttons.BACK) 	 fprintf(stdout, "Button Back pressed...\n");
		if(buttons.LS_PRESS) fprintf(stdout, "Button Left-stick pressed...\n");
		if(buttons.RS_PRESS) fprintf(stdout, "Button Right-stick pressed...\n");
		if(buttons.LB) 		 fprintf(stdout, "Button LB pressed...\n");
		if(buttons.RB) 		 fprintf(stdout, "Button RB pressed...\n");
		if(buttons.LOGO) 	 fprintf(stdout, "Button Logo pressed...\n");
		if(buttons.A) 		 fprintf(stdout, "Button A pressed...\n");
		if(buttons.B) 		 fprintf(stdout, "Button B pressed...\n");
		if(buttons.X) 		 fprintf(stdout, "Button X pressed...\n");
		if(buttons.Y) 		 fprintf(stdout, "Button Y pressed...\n");

		if(buttons.Left_trigger > 0)  printf("Left trigger value = %d\n", buttons.Left_trigger);
		if(buttons.Right_trigger > 0) printf("Right trigger value = %d\n", buttons.Right_trigger);

		// if(buttons.Left_stick_X < -THRESHOLD || buttons.Left_stick_X > THRESHOLD)
		// {
		// 	printf("Left stick X value = %d\n", buttons.Left_stick_X);
  //   	}
  //   	if(buttons.Left_stick_Y < -THRESHOLD || buttons.Left_stick_Y > THRESHOLD)
		// {
		// 	printf("Left stick Y value = %d\n", buttons.Left_stick_Y);
  //   	}
  //   	if(buttons.Right_stick_X < -THRESHOLD || buttons.Right_stick_X > THRESHOLD)
		// {
		// 	printf("Right stick X value = %d\n", buttons.Right_stick_X);
  //   	}
  //   	if(buttons.Right_stick_Y < -THRESHOLD || buttons.Right_stick_Y > THRESHOLD)
		// {
		// 	printf("Right stick Y value = %d\n", buttons.Right_stick_Y);
  //   	}

    	usleep(10000);
    }

	libusb_close(h); //close the device we opened
	libusb_exit(ctx); //needs to be called to end the

	return (0);
}