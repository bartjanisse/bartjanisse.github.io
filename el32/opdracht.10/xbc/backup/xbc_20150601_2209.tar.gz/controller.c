/** @file controller.c
 *  @brief Function prototypes for the console driver.
 *
 *  This contains the prototypes for xxxxxxxxxxxxxxxxxxxxxxx
 *
 *  @author A.W Janisse
 *  @bug No known bugs.
 */

#include <libusb-1.0/libusb.h>
#include <stdio.h>
#include "controller.h"


int
rumble(libusb_device_handle *handle, uint16_t speed)
{
	uint8_t 	rumble[] = { 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
 	int 		error, transferred;

 	rumble[3] = speed >> 8;
 	rumble[4] = speed;
	
	if ((error = libusb_interrupt_transfer(handle, EP_OUT, rumble, sizeof rumble, &transferred, 0)) != 0) 
	{
		fprintf(stderr, "Transfer rumble failed: %d\n", error);
		return (-1);
	}

	return (0);
}

int 
setLeds(libusb_device_handle *handle, Leds led)
{
	uint8_t 	data[] = { 0x01, 0x03, 0x00 };
 	int 		error, transferred;

	data[2] = led;

	if ((error = libusb_interrupt_transfer(handle, EP_OUT, data, sizeof data, &transferred, 0)) != 0) 
	{
		fprintf(stderr, "Transfer setLeds failed: %d\n", error);
		return (-1);
	}


	return (0);
}

int 
getInput(libusb_device_handle *handle, Buttons *buttons)
{
	uint8_t 	input[20];
	int 		error, transferred;

	if ((error = libusb_interrupt_transfer(handle, EP_IN, input, sizeof input, &transferred, 0)) != 0) 
	{
		fprintf(stderr, "Transfer setLeds failed: %d\n", error);
		return (-1);
	}    

	buttons->D_UP 	  = input[2] & 0x01;
	buttons->D_DN 	  = input[2] & 0x02;
	buttons->D_LEFT   = input[2] & 0x04;
	buttons->D_RIGHT  = input[2] & 0x08;
	buttons->START 	  = input[2] & 0x10;
	buttons->BACK 	  = input[2] & 0x20;
	buttons->LS_PRESS = input[2] & 0x40;
	buttons->RS_PRESS = input[2] & 0x80;

	buttons->LB 	  = input[3] & 0x01;
	buttons->RB 	  = input[3] & 0x02;
	buttons->LOGO     = input[3] & 0x04;
	buttons->SPARE    = input[3] & 0x08;
	buttons->A        = input[3] & 0x10;
	buttons->B        = input[3] & 0x20;
	buttons->X        = input[3] & 0x40;
	buttons->Y        = input[3] & 0x80;

	buttons->Left_trigger  = input[0x04];
	buttons->Right_trigger = input[0x05];
	buttons->Left_stick_X  = input[0x07] << 8 | input[0x06];
	buttons->Left_stick_Y  = input[0x09] << 8 | input[0x08];
	buttons->Right_stick_X = input[0x0b] << 8 | input[0x0a];
	buttons->Right_stick_Y = input[0x0d] << 8 | input[0x0c];

	return (0);
}


