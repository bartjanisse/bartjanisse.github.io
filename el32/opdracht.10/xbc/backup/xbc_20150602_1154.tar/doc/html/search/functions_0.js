var searchData=
[
  ['getdevices',['getDevices',['../devices_8c.html#a9d85258426e1fb8a6177467f4575bcfd',1,'getDevices(libusb_device **devices):&#160;devices.c'],['../devices_8h.html#a9d85258426e1fb8a6177467f4575bcfd',1,'getDevices(libusb_device **devices):&#160;devices.c']]],
  ['getinput',['getInput',['../controller_8c.html#ac99caf44600d91c9e514d3e5e0f0cfa6',1,'getInput(libusb_device_handle *handle, Buttons *buttons):&#160;controller.c'],['../controller_8h.html#ac99caf44600d91c9e514d3e5e0f0cfa6',1,'getInput(libusb_device_handle *handle, Buttons *buttons):&#160;controller.c']]]
];
