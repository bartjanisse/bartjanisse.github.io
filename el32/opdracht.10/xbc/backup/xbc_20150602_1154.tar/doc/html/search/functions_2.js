var searchData=
[
  ['printalldevices',['printAllDevices',['../devices_8c.html#aba84b8560d0c66badfc142ca40b702de',1,'printAllDevices(libusb_device **devices):&#160;devices.c'],['../devices_8h.html#aba84b8560d0c66badfc142ca40b702de',1,'printAllDevices(libusb_device **devices):&#160;devices.c']]]
];
