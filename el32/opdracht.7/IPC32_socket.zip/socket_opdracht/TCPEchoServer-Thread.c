#include <pthread.h>

#include "Auxiliary.h"
#include "AcceptTCPConnection.h"
#include "CreateTCPServerSocket.h"
#include "HandleTCPClient.h"

static void * myThread (void * arg);            /* thread that does the work */

int main (int argc, char *argv[])
{
    int         servSock;     /* Socket descriptor for server */
    int         clntSock;     /* Socket descriptor for client */
    pthread_t   threadID;     /* Thread ID from pthread_create() */
    bool        to_quit = false;

    parse_args (argc, argv);

    servSock = CreateTCPServerSocket (argv_port);

    while (to_quit == false)                /* run until someone indicates to quit... */
    {
        clntSock = AcceptTCPConnection (servSock);

        // TODO: schrijf hier de code om een thread myThread() te creeeren (en te laten draaien)
        // maak gebruik van de POSIX operatie pthread_create()
        //
        // zorg dat op de juiste plaatsen de clntSock en de servSock gesloten worden 
        // (namelijk op al die plaatsen waar je ze dan niet meer nodig hebt)

    }
    
    // server stops...
}

static void *
myThread (void * threadArgs)
{
    // TODO: schrijf hier de code om client-data af te handelen
    // maak gebruik van HandleTCPClient()
    //  
    // Tip: gebruik info(), info_d(), info_s() operaties om zichtbaar te maken wat er gebeurt
    //
    // let op: hierin moet OOK een aanroep van pthread_detach() staan

    return (NULL);
}
