#ifndef _HANDLE_TCP_CLIENT_H_
#define _HANDLE_TCP_CLIENT_H_

extern void HandleTCPClient (int clntSocket);   /* TCP client handling function */

#endif
