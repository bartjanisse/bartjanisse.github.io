#include <stdlib.h>     // for atoi() and exit()
#include <unistd.h>     // for fork()
#include <sys/wait.h>   // for waitpid()

#include "Auxiliary.h"
#include "AcceptTCPConnection.h"
#include "CreateTCPServerSocket.h"
#include "HandleTCPClient.h"

int main(int argc, char *argv[])
{
    int     servSock;                  /* Socket descriptor for server */
    int     clntSock;                  /* Socket descriptor for client */
    pid_t   processID;                 /* Process ID from fork() */
    bool    to_quit = false;

    parse_args (argc, argv);

    servSock = CreateTCPServerSocket (argv_port);

    while (to_quit == false)                /* run until someone indicates to quit... */
    {
        clntSock = AcceptTCPConnection (servSock);

        // TODO: schrijf de code om het volgende te realiseren:
        //
        // fork() een nieuw process en implementeer het volgende:
        // * check of de fork() mislukt is
        //   in dat geval moet je het proces beeindigen (fatal error...)
        // * check of je het child proces bent
        //   in dat geval moet je:
        //   - de communicatie met de client afhandelen (gebruik HandleTCPClient())
        //   - het proces beeindigen
        // * check of je de parent bent
        //   in dat geval moet je:
        //   - opnieuw op de volgende klant wachten (opnieuw in de while-loop)
        // * zorg dat op de juiste plaatsen de clntSock en de servSock gesloten worden 
        //   (namelijk op al die plaatsen waar je ze dan niet meer nodig hebt)
        //
        // Tip: gebruik info() en/of info_d() operaties om zichtbaar te maken wat er gebeurt
    }
    
    // server stops...
}
