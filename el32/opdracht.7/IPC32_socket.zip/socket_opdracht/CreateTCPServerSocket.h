#ifndef _CREATE_TCP_SERVER_SOCKET_H_
#define _CREATE_TCP_SERVER_SOCKET_H_

extern int CreateTCPServerSocket (unsigned short port); /* Create TCP server socket */

#endif
