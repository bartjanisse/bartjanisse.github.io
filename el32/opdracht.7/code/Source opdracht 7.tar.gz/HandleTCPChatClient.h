#ifndef _HANDLE_TCP_CHAT_CLIENT_H_
#define _HANDLE_TCP_CHAT_CLIENT_H_

extern void HandleTCPChatClient (int clntSocket);   /* TCP client handling function */

#endif
